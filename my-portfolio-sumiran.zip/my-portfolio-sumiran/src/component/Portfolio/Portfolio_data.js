const Portfolio_data = [
  {
    id: 1,
    category: "FRONT END DEVELOPMENT",
    totalLike: "600",
    title: "The services provide for design ",
    image: "https://i.pinimg.com/564x/65/0d/b1/650db192e5a43266845beb4d27f2749a.jpg",
  },
  {
    id: 2,
    category: "REACT DEVELOPER",
    totalLike: "750",
    title: "Mobile app landing design & maintain",
    image: "https://i.pinimg.com/564x/92/1f/a6/921fa665998d0c7d5d16bdd7e18a9a9d.jpg",
  },
  {
    id: 3,
    category: "FULL STACK DEVELOPER",
    totalLike: "630",
    title: "Logo design creativity & Application ",
    image: "https://i.pinimg.com/564x/42/8a/93/428a93ef806292fd39a8b6a3dccfaa8f.jpg",
  },
  {
    id: 4,
    category: "WEB DEVELOPER",
    totalLike: "360",
    title: "Mobile app landing design & Services",
    image: "https://i.pinimg.com/564x/69/41/d0/6941d0d48d80d6b6ee7f58e219918216.jpg",
  },
  {
    id: 5,
    category: "WEB DESIGN",
    totalLike: "280",
    title: "Design for tecnology & services",
    image: "https://i.pinimg.com/564x/93/5b/5b/935b5b7fbb8063e63cee9eeaa77dd87c.jpg",
  },
  {
    id: 6,
    category: "WEB DESIGN",
    totalLike: "690",
    title: "App for tecnology & services",
    image: "https://i.pinimg.com/564x/e5/91/87/e5918753b0675b4ac038cd42bc835107.jpg",
  },
]
export default Portfolio_data
