import React from "react"
import logo1 from "./pic/logo1.png"

const Footer = () => {
  return (
    <>
      <footer>
        <div className='conatiner text-center top'>
          <div className='img'>
            <img style={{width:"100px"}}src={logo1} alt='' />
          </div>
          <p>© 2023. All rights reserved by Sumiran Biswas.</p>
        </div>
      </footer>
    </>
  )
}

export default Footer
