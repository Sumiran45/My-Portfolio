const ResumeApi = [
  {
    id: 1,
    category: "education",
    year: "!0th class (2018 - 2019)",
    title: "Saint Paul's Convent School",
    desc: "The education should be very interactual. Ut tincidunt est ac dolor aliquam sodales. Phasellus sed mauris hendrerit, laoreet sem in, lobortis mauris hendrerit ante.",
    rate: "4.30/5",
  },
  {
    id: 2,
    category: "education",
    year: "12th class (2019 - 2020) ",
    title: "Saint Paul's Convent School",
    desc: "Maecenas finibus nec sem ut imperdiet. Ut tincidunt est ac dolor aliquam sodales. Phasellus sed mauris hendrerit, laoreet sem in, lobortis mauris hendrerit ante.",
    rate: "4.50/5",
  },
  {
    id: 3,
    category: "education",
    year: "B.Tech ( CSE )(2020 - 2024) ",
    title: "Acropolis Institute Of Technology and Research",
    desc: "If you are going to use a passage. Ut tincidunt est ac dolor aliquam sodales. Phasellus sed mauris hendrerit, laoreet sem in, lobortis mauris hendrerit ante.",
    rate: "4.80/5 ",
  },
  {
    id: 4,
    category: "experience",
    year: "Minor Project (Sep 2022 - Dec 2022) ",
    title: "Front End Development",
    desc: "Worked on a scholarship portal and worked as a front end developer in the project. Gathered all the requirement and designed all the wireframe of the project",
    rate: "4.70/5 ",
  },
  {
    id: 5,
    category: "experience",
    year: "Oasis Infobyte ( Dec 2022 - Jan 2022) ",
    title: "Web Development",
    desc: "Designed a Blog website app. Gathered requiremet for the website and designed the front end for the website. created some of the pages like Blog category, add blogs etc. ",
    rate: "4.45/5 ",
  },
  {
    id: 6,
    category: "experience",
    year: "Virtual Visit ( Jan 2023 - Present) ",
    title: "Full Stack Development",
    desc: "Designing a Virtual visit pilgrimages web site. I am working as a full stack developer in it. Designing all the pages and wireframe for the project and managed the database using mongoDB.",
    rate: "5.00/5 ",
  },
]

export default ResumeApi
