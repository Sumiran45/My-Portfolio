const data = [
  {
    id: 1,
    image: "",
    title: "Front End developer",
    desc: "I throw myself down among the tall grass by the stream as I lie close to the earth.",
  },
  {
    id: 2,
    image: "",
    title: "web Development",
    desc: " It uses a dictionary of over 200 Latin words, combined witha handful of model sentence.",
  },
  {
    id: 3,
    image: "",
    title: "Full Stack Development",
    desc: "I throw myself down among the tall grass by the stream as I lie close to the earth.",
  },
  {
    id: 4,
    image: "",
    title: "React Developer",
    desc: "There are many variations of passages of Lorem Ipsum	available, but the majority.",
  },
  {
    id: 5,
    image: "",
    title: "JavaScript Framework",
    desc: "always free from repetition, injected humour, or non-characteristic words etc.",
  },
  {
    id: 6,
    image: "",
    title: "Personal Portfolio March",
    desc: " It uses a dictionary of over 200 Latin words, combined with a handful of model sentence.",
  },
]
export default data
