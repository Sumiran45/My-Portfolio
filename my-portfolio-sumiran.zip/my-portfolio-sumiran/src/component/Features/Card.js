import React from "react"

const Card = (props) => {
  return (
    <>
      <div className='box btn_shadow'>
        <img src={props.image} alt='' />
        <h2>{props.title}</h2>
        <p>{props.desc}</p>
        <a href='/'>
          <i style={{
 border: "solid black",
 borderWidth: "0 3px 3px 0",
 display: "inline-block",
 padding: "3px",
 transform: "rotate(-135deg)",
//  -webkit-transform: "rotate(-135deg)"

          }}className='arrow up'></i>
        </a>
      </div>
    </>
  )
}

export default Card
